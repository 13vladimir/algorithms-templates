# A. Дек
# ID посылки: 106148716

from typing import List, Tuple


class NoItemsError(Exception):
    def __init__(self):
        pass


class StackOverflowError(Exception):
    def __init__(self):
        pass


class Queue:
    def __init__(self, max_size_deque: int):
        self.queue = [None] * max_size_deque
        self.max_n = max_size_deque
        self.head = 0
        self.tail = -1
        self.size = 0

    def is_empty(self) -> bool:
        return self.size == 0

    def is_full(self) -> bool:
        return self.size == self.max_n

    def calculation_push_front(self):
        self.head = (self.head - 1) % self.max_n

    def calculation_push_back(self):
        self.tail = (self.tail + 1) % self.max_n

    def calculation_pop_front(self):
        self.head = (self.head + 1) % self.max_n

    def calculation_pop_back(self):
        self.tail = (self.tail - 1) % self.max_n

    def push_front(self, value: int) -> None:
        if self.is_full():
            raise StackOverflowError
        self.calculation_push_front()
        self.queue[self.head] = value
        self.size += 1

    def push_back(self, value: int) -> None:
        if self.is_full():
            raise StackOverflowError
        self.calculation_push_back()
        self.queue[self.tail] = value
        self.size += 1

    def pop_front(self) -> int:
        if self.is_empty():
            raise NoItemsError
        value = self.queue[self.head]
        self.calculation_pop_front()
        self.size -= 1
        return value

    def pop_back(self) -> int:
        if self.is_empty():
            raise NoItemsError
        value = self.queue[self.tail]
        self.calculation_pop_back()
        self.size -= 1
        return value


def read_input() -> Tuple[int, int, List[int]]:
    amount_commands = int(input())
    max_size_deque = int(input())
    commands = [list(map(str, input().split()))
                for _ in range(amount_commands)]
    return max_size_deque, commands


def main():
    max_size_deque, commands = read_input()
    queue = Queue(max_size_deque)
    for arg in commands:
        try:
            print(getattr(queue, arg[0])()) if len(arg) == 1 else getattr(
                queue, arg[0])(arg[1])
        except (NoItemsError, StackOverflowError):
            print('error')


if __name__ == '__main__':
    main()
